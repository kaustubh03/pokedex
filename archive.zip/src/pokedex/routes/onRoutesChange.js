export const onRouteChangeEvent = data => {
  // Please add common functionality of app here
};
