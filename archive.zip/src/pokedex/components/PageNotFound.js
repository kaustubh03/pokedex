import React, { PureComponent } from 'react';

class PageNotFound extends PureComponent {
  render() {
    return <div>404 Not Found !</div>;
  }
}

export default PageNotFound;
