// import {
//     FETCH_LEAD_DATA,
//   } from '../constants/actionTypes';

//   export function saveLeadDataToStore(fetchLeadData) {
//     return async (dispatch) => {
//     dispatch({
//         type: FETCH_LEAD_DATA,
//         payload: fetchLeadData
//       });
//     }
//   }
