export const testData = [
    {
        "name": "clefable",
        "url": "https://pokeapi.co/api/v2/pokemon/36/"
    },
    {
        "name": "abra",
        "url": "https://pokeapi.co/api/v2/pokemon/63/"
    },
    {
        "name": "kadabra",
        "url": "https://pokeapi.co/api/v2/pokemon/64/"
    },
    {
        "name": "krabby",
        "url": "https://pokeapi.co/api/v2/pokemon/98/"
    },
    {
        "name": "electabuzz",
        "url": "https://pokeapi.co/api/v2/pokemon/125/"
    },
    {
        "name": "kabuto",
        "url": "https://pokeapi.co/api/v2/pokemon/140/"
    },
    {
        "name": "kabutops",
        "url": "https://pokeapi.co/api/v2/pokemon/141/"
    },
    {
        "name": "sableye",
        "url": "https://pokeapi.co/api/v2/pokemon/302/"
    },
    {
        "name": "swablu",
        "url": "https://pokeapi.co/api/v2/pokemon/333/"
    },
    {
        "name": "absol",
        "url": "https://pokeapi.co/api/v2/pokemon/359/"
    },
    {
        "name": "gabite",
        "url": "https://pokeapi.co/api/v2/pokemon/444/"
    },
    {
        "name": "abomasnow",
        "url": "https://pokeapi.co/api/v2/pokemon/460/"
    },
    {
        "name": "karrablast",
        "url": "https://pokeapi.co/api/v2/pokemon/588/"
    },
    {
        "name": "vullaby",
        "url": "https://pokeapi.co/api/v2/pokemon/629/"
    },
    {
        "name": "flabebe",
        "url": "https://pokeapi.co/api/v2/pokemon/669/"
    },
    {
        "name": "pumpkaboo-average",
        "url": "https://pokeapi.co/api/v2/pokemon/710/"
    },
    {
        "name": "charjabug",
        "url": "https://pokeapi.co/api/v2/pokemon/737/"
    },
    {
        "name": "crabrawler",
        "url": "https://pokeapi.co/api/v2/pokemon/739/"
    },
    {
        "name": "crabominable",
        "url": "https://pokeapi.co/api/v2/pokemon/740/"
    },
    {
        "name": "pumpkaboo-small",
        "url": "https://pokeapi.co/api/v2/pokemon/10027/"
    },
    {
        "name": "pumpkaboo-large",
        "url": "https://pokeapi.co/api/v2/pokemon/10028/"
    },
    {
        "name": "pumpkaboo-super",
        "url": "https://pokeapi.co/api/v2/pokemon/10029/"
    },
    {
        "name": "absol-mega",
        "url": "https://pokeapi.co/api/v2/pokemon/10057/"
    },
    {
        "name": "abomasnow-mega",
        "url": "https://pokeapi.co/api/v2/pokemon/10060/"
    },
    {
        "name": "sableye-mega",
        "url": "https://pokeapi.co/api/v2/pokemon/10066/"
    }
];