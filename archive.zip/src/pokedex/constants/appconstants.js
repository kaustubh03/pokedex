export default {
  CHECKIN_HEADING_TEXT: 'Offer Start Date',
  CHECKOUT_HEAD_TEXT: 'and Offer End date',
  CALENDAR_BTN_ERROR_TEXT: 'Maximum offer duration allowed is 3 months',
  GENERIC_ERROR: 'Oops, something went wrong! Please try again.',
  OTPGENERICERROR:
    'We could not connect to the server. Please try again later.',
  LOAN_OFFERING_SCREEN: 'loanOffering',
  LOAN_DISBURSAL_SCREEN: 'loanDisbursal',
  LOAN_ADDITIONAL_SCREEN: 'additionalDetail',
  LOAN_TIMELINE_SCREEN: 'timeline',
  LOAN_REJECTION_SCREEN: 'loanReject',
  REQUEST_TIME_OUT: 'REQUEST_TIME_OUT',
  NO_NETWORK: 'NO_NETWORK',
  ERROR: 'Error'
};
// const obj = {
//   en: {
//     errormsg: 'sdljkfnsdklnds',
//     btnText: 'sdkjbsdjb'
//   },
//   hi: {
//     errormsg: 'hindisdjkfbsdkjfbsdfkjdsbfdsfjki',
//     btnText: 'sdlkjfbnsdkljfbnsdklfbnsadlfkbnsdflkdj'
//   }
// }

// const lg = 'en';
// const constants = obj[lg];

// export default constants;
