export const baseUrl = "https://pokeapi.co/api/v2/";

export const fetchAllPokemons = () =>{
    return `${baseUrl}pokemon/`;
}